package com.example.android.musicalstructure;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NowPlayingActivity extends AppCompatActivity {

    Button mainMenu;
    Button playButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nowplaying);

        mainMenu = (Button) findViewById(R.id.main_menu_button);//get id of button

        mainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent button1Intent = new Intent(NowPlayingActivity.this, MainActivity.class);
                startActivity(button1Intent);
            }
        });

        playButton = (Button) findViewById(R.id.play_button);//get id of button

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(),"Playing Song",Toast.LENGTH_SHORT).show();



            }
        });

    }

}
