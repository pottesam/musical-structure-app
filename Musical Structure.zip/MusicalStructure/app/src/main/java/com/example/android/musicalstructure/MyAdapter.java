package com.example.android.musicalstructure;

import android.widget.ArrayAdapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class MyAdapter extends ArrayAdapter<songArtist> {
    public MyAdapter(Context context, ArrayList<songArtist> pWords) {
        super(context,0, pWords);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View songlistView = convertView;

        if(songlistView == null) {
            songlistView = LayoutInflater.from(getContext()).inflate(
                    R.layout.songlist, parent, false);
        }
        songArtist local_songArtist = getItem(position);

        TextView songTextView = songlistView.findViewById(R.id.songTextView);
        songTextView.setText(local_songArtist.getmSongName());
        


        return songlistView;
    }
}

