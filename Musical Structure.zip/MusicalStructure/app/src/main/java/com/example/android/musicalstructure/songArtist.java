package com.example.android.musicalstructure;

public class songArtist {

        private String mSongName;

        private String mArtistName;

        public songArtist(String songName, String artistName) {
            mSongName = songName;
            mArtistName = artistName;
        }

        public String getmSongName() {
            return mArtistName;
        }

        public String getmArtistName() {
            return mSongName;
        }

    }


