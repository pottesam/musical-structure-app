package com.example.android.musicalstructure;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;import android.widget.ListView;
import android.widget.Toast;

public class songs extends AppCompatActivity {

    ListView songList;
    Button artistsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songlist);
        ArrayList<songArtist> music = new ArrayList<songArtist>();

        music.add(new songArtist("Old Man", "Neil Young"));
        music.add(new songArtist("Summertime Sadness", "Lana Del Ray"));
        music.add(new songArtist("Doin Time", "Sublime"));
        music.add(new songArtist("Casey Jones", "Greatful Dead"));
        music.add(new songArtist("Happy Song", "Bring me the Horizon"));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        MyAdapter adapter = new MyAdapter(this, music);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) findViewById(R.id.songListView);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);
    }






    }


